#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <absacc.h>

#ifndef XADD
#define XADD 0x4000
#define XRAM 0x0000

#endif


/***************************************************************************/
/******************* variables and constants ********************************/
/****************************************************************************/


#define welcomeString  "Visitor Registration System."
#define dataLogger "Data Logger."
sbit rs = P1^7;
sbit rw = P1^6;
sbit en = P1^5;




/**************************************************************/
/******************* functions ********************************/
/**************************************************************/


void delay()
{
    unsigned int k, l;
    for (k = 0; k < 100; k++)
    {
        for (l = 0; l < 100; l++)
        {
            // Some action here or nothing to do
        }
    }
}


void delay_us(int time_us)
{
    unsigned int k, l;
    for (k = 0; k < time_us; k++)
    {
        for (l = 0; l < 100; l++)
        {
            // Some action here or nothing to do
        }
    }
}


void uart_send(unsigned char *s)
{
    while(*s) {
        SBUF=*s++;
        while(TI==0);
        TI=0;
    }
}


void lcdcmd(unsigned char dat)
{
    P2 = dat;
    rs = 0;
    rw = 0;
    en = 1;
    delay();
    en = 0;
}

void lcddat(unsigned char dat)
{
    P2 = dat;
    rs = 1;
    en = 1;
    delay();
    en = 0;
}

void lcddis(unsigned char *s, unsigned char r)
{
    unsigned char w;
    for (w = 0; w < r; w++) 
    {
        lcddat(s[w]);
        //delay();
    }
}


void lcdSetCursor(int ind, int sp){
   int i;
   char cmd = 0x80;
   
	if(ind == 1){
		cmd = 0xC0;
	}else if(ind == 2){
		cmd=0x94;
	}else if(ind == 3){
		cmd=0xD4;
	}
    
    lcdcmd(cmd);
	for(i = 0;i < sp;i++){
		lcdcmd(0x06);
	}
}
/*
void lcdconv(unsigned char num)
{
    lcddat((num / 10) + 0x30); // Convert tens digit to ASCII
    lcddat((num % 10) + 0x30); // Convert ones digit to ASCII
}

*/
void lcdHome(){
    lcdcmd(0x01);

    lcddis("      VISITOR", 13);
    lcdcmd(0xC0);
    delay();
    lcddis("    REGISTRATION", 16);
    lcdcmd(0x94);
    delay();
    lcddis("       SYSTEM", 13);
    lcdcmd(0xD4);
    lcddis("  PRESS > BUTTON",16);
    delay();
}

void lcdEntryChoise(int index){
    lcdcmd(0x01);
	lcdcmd(0x0D);
	lcdcmd(0x80);lcddis("Are you",8);
	lcdcmd(0xC0);lcddis("  1.Entering?", 14);
	lcdcmd(0x94);lcddis("  2.Exiting?", 13);
	lcdcmd(0xD4);lcddis("  3.Viewing Data?", 17);
	lcdcmd(0x0D);
   
	lcdSetCursor(index+1,17);
	lcddis("<>", 2);
	lcdcmd(0xD4);
    
}



void lcdDepChoise(int index){
   lcdcmd(0x01);
   lcdcmd(0x0D);
   lcdcmd(0x80);lcddis("Select a Depart",17);
   lcdcmd(0xC0);lcddis("  1.ADMNISTRATION", 19);
   lcdcmd(0x94);lcddis("  2.ETE", 7);
   lcdcmd(0xD4);lcddis("  3.CEIT", 8);
   lcdcmd(0x0D);
   
   lcdSetCursor(index+1,17);
   lcddis("<>", 2);
   lcdcmd(0xD4);
}
unsigned char getKey(){ 
    unsigned char state =0, ret = 0;
   

//capture for the button pressed 
	do{
	   state = P1 & 0x1F;
	   if (state == 0x1E)   // up pressed
        {ret = 1;}
		else if(state == 0X1D)  //enter pressed
        {ret = 2;}
		else if(state == 0X1B)  //down pressed
        {ret = 3;}
		else if(state == 0X17)  // return pressed
        {ret = 4;}
		else if(state == 0X0F)  // okay pressed
		{ret = 5;}  
        }while(ret == 0);
   led = 1;
   return ret;
}
   
void charToAscii(unsigned char value, char* toPrint){
   unsigned char num,rem;
  int counter= 0;
   num = value;
   do{
      num = (num / 10) + 0x30; // Convert tens digit to ASCII
      rem = (num % 10) + 0x30; // Convert ones digit to ASCII
      toPrint[counter] = rem;
      counter++;
   }while(num > 10);
   
   toPrint[counter] = num;
}
 
void clearMem(){
   int i =0;
   for(i=0;i< 255;i++){
      XBYTE[XADD + i] = 0x00;
      }
   }



void dataLoger(){
   int j =0;
   unsigned char counter;
   unsigned char depLeaves[3];
   unsigned char depEnters[3];
   char* sep = "| ";
   unsigned char strtAddr = XBYTE[XADD];
   unsigned char endAddr = XBYTE[XADD + 2];
   unsigned char dep1Enter = XBYTE[strtAddr + 4];
   unsigned char dep2Enter= XBYTE[strtAddr + 5];
   unsigned char dep3Enter= XBYTE[strtAddr + 6];
   unsigned char dep1Leaves= XBYTE[strtAddr + 7];
   unsigned char dep2Leaves= XBYTE[strtAddr + 8];
   unsigned char dep3Leaves= XBYTE[strtAddr + 9];
    depLeaves[1] = '0'+dep1Leaves;
    depLeaves[2] = '0'+dep2Leaves;
    depLeaves[3] = '0'+dep3Leaves;
    depEnters[1] = '0'+dep1Enter;
    depEnters[2] = '0'+dep2Enter;
    depEnters[3] = '0'+dep3Enter;
   
   
   uart_send(welcomeString);
   uart_send("\r");
   uart_send(dataLogger);
   uart_send("\r");
   uart_send("|INDEX|DEPARTMENT|ENTRY|LEAVES|");
   uart_send("\r");
   
   do{
      
      char leaveStr[3];
      char enterStr[3]; 
      char* depStr ;
      char* number ;
      char* w = "|"; 
      leaveStr[0] =  depLeaves[j];
      enterStr[0] = depEnters[j];
      if(j == 1){
         depStr = " CEIT ";
         number = "2";
         }
      else if(j ==2){
         depStr = " ETE";
         number = "3";
         }
      else{ 
         depStr = "Administration";
         number = "1";
         }
    uart_send(sep);
    uart_send(number);
    uart_send( sep);
    uart_send( depStr);
    uart_send( sep);
    //uart_send(number);
    uart_send( &leaveStr);
    uart_send( sep);
    //uart_send(number);
    uart_send( &enterStr);
    uart_send( sep);
      
      uart_send("\r");
      counter++;
      j=j+1;
     }while(j<3);
    //uart_send("|--|-----|----|-------|---|");
    uart_send(sep);
     
   
    
}
   
void record(unsigned char act,unsigned char dep){
   unsigned char strtAddr = XBYTE[XADD];
   unsigned char endAddr = XBYTE[XADD + 2];
   unsigned char dep1Enter = XBYTE[strtAddr + 4];
   unsigned char dep2Enter= XBYTE[strtAddr + 5];
   unsigned char dep3Enter= XBYTE[strtAddr + 6];
   unsigned char dep1Leaves= XBYTE[strtAddr + 7];
   unsigned char dep2Leaves= XBYTE[strtAddr + 8];
   unsigned char dep3Leaves= XBYTE[strtAddr + 9];
   if(act == 0) //entering 
   {
      if(dep == 1){dep1Enter++;}
      else if(dep == 2){dep2Enter++;}
      else if(dep == 3){dep3Enter++;}
      
      }
      
  else if(act == 1){  //exiting
     
      if(dep == 1){dep1Leaves--;}
      else if(dep == 2){dep2Leaves--;}
      else if(dep == 3){dep3Leaves--;}
     }

   XBYTE[strtAddr + 4] = dep1Enter ;
   XBYTE[strtAddr + 5] = dep2Enter;
   XBYTE[strtAddr + 6] = dep3Enter;
   XBYTE[strtAddr + 7] = dep1Leaves;
   XBYTE[strtAddr + 8] = dep2Leaves;
   XBYTE[strtAddr + 9] = dep3Leaves;
   
     
     
}  
     
