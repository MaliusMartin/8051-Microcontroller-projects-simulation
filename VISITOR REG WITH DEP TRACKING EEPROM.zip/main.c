/*
                                the logical addressing table 
 _________________________________________________________________________________________________
|      Memory type	         |     starting address               |       ending address          |
|----------------------------|------------------------------------|-------------------------------|
|  1.PROM                    |        0x0000H                     |        0x3FFFH                |
|----------------------------|------------------------------------|-------------------------------|
|  2.RAM                     |        0x0000H                     |        0x3FFFH                |
|----------------------------|------------------------------------|-------------------------------|
|  3.ROM                     |        0x4000H                     |        0xBFFFH                |
|____________________________|____________________________________|_______________________________|

*/

//#include <mcs51reg.h>
#include<reg51.h>
#include <String.h>
#include <absacc.h>
#include <stdio.h>

// Department A
sbit upButtn = P1^0; // up Button
sbit rightButtn = P1^1; // right Button
sbit downButtn = P1^2; // down Button
sbit leftbuttn = P1^3; // left Button
sbit  okButtn = P1^4; // okay/select Button
sbit led = P3^5;




char state;
unsigned int sectionCounter = 0;
unsigned int indCounter = 0;
unsigned char section = 0;
unsigned char okayCounter = 0;
unsigned char okay = 0;
unsigned char lineIndex = 0;
unsigned char pKey = 0;


#define XADD 0x03a0
#define XRAM 0x0000

#include "functions.h"



void lcdcmd(unsigned char);
void lcddat(unsigned char);
void lcdSetCursor(int ind, int sp);
void delay();
void delay_us(int time_us);
void lcddis(unsigned char *, unsigned char);
void lcdconv(unsigned char);
void lcdHome();
void uart_send(unsigned char *s);
void lcdEntryChoise(int index);
void lcdDepChoise(int index);
unsigned char getKey();
void clearMem();
void dataLoger();
void charToAscii(unsigned char value, char* toPrint);
char numToAscii(unsigned char value, unsigned char size);
char* concatenate(const char* str1, const char* str2);



void main()
{


   int proc[3] = {0,0,0};
   int z = 0;
   unsigned char lastSection =0;
   unsigned char lastlineIndex =0;

   P0=0x00;
   P0=0xFF;
   //uart_begin1. 
   SCON=0x50; //Mode 1, Baudrate generating using Timer 1
   TMOD=0x20; //Timer 1 Auto reload mode
   TH1=TL1=0xfd; //Values Calculated for 9600 baudrate
   TR1=1; //Run the timer   
   //uart_send(welcomeString);
   clearMem();
   dataLoger();
   lcdcmd(0x38);
   lcdcmd(0x01);
   lcdcmd(0x10);
   lcdcmd(0x0D);
   led = 1;
   lcdcmd(0xC0);
   //lcddis("         TO        ", 20);
   //lcdcmd(0x94);
   //lcddis("       COICT       ", 20);
   //delay();
   lcdHome();
   
   
   led = 0;
    sectionCounter = 0;
    okay = 0;
    indCounter = 0;
    while(1){

       
       
       if(section == 0){
          lcdHome();
        }
//capture for the button pressed 
       
       
       pKey = getKey();
       delay_us(1000);
       led = 0;
       
//capture for the action
		if(pKey == 5 ){  // okay
		   okayCounter++;
		}
		if(pKey == 2 ){  // right
		   sectionCounter++;
		   }
		if(pKey == 4 ){  // left
		   if(sectionCounter > 0){sectionCounter--;}
		   }
		if(pKey == 1 ){   //up
		   if(indCounter > 0){indCounter--;}
		   }
		if(pKey == 3 ){  //down
		   indCounter++;
		   }
           //for(z=0;z<=pKey;z++){led = 1;delay_us(1000/pKey);led = 0;delay_us(1000/pKey);}
           
           okay  =   (okayCounter + 2) % 2;
		   section = (sectionCounter + 4) % 4;
		   lineIndex = (indCounter + 4) % 4;

           
           
		   if(section == lastSection){continue;} 
           if(section == 1){   // sections
                  proc[1] = lineIndex;
                  proc[0] = section;
                  lcdEntryChoise(lineIndex);continue;
           }
           else if(section == 2){
              proc[0] = section;
               if(lineIndex == 3){  // IF SELECTED DATA LOGGING 
                  dataLoger();
                  section = 3;
                  continue;
               }
               
               proc[1] = lineIndex;
               lcdDepChoise(lineIndex);
               
            }
               
           else if(section == 3){ 
              proc[2] = lineIndex;
              proc[0] = section;
              
              lcdcmd(0x01);
              lcdcmd(0xC0);
              lcddis("Loading..", 9);
              delay_us(1000);
              delay_us(160); 
             if(proc[1] == 0 ){ // action is entering
                lcddis("Saving..", 9);
                delay_us(1000);
                record(proc[1], proc[2]);
                section = 0;
             }
             else if(proc[1] == 1){  //action is exiting
                lcdcmd(0x01);
                lcddis("Welcome again", 12);
                record(proc[1], proc[2]);
                delay_us(1300);                
                section = 0;
                }
             else if(proc[1] == 2){  //action is data logging
                dataLoger();
                section = 0;
                }
              
              
           }
            
          
		   
		    if(lineIndex == lastlineIndex){continue;}
 
   

         
         lastlineIndex = lineIndex;
         lastSection = section;


	}
}
 